const name = document.getElementById("name")
const number = document.getElementById("number")
const frame = document.getElementById("frame")

