// $(document).ready(function(){
// alert('connected')
//     $('.search').on('submit',function(){
//         var query=$(this).attr('value');
//         req=$.ajax({
//             url : '/search',
//             type : 'POST',
//             data : {
//                 q=query,
//             }
//         });
//         alert("success")
//     });
// });